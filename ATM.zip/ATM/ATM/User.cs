﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ATM
{
    class User
    {

        public string Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }

        public int Balance { get; set; }


    }
}
