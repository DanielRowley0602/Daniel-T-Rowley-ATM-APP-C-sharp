﻿using System;
using System.Collections.Generic;

namespace ATM
{
    class Program
    {
        static void Main(string[] args)
        {
            //This code creates two user objects, gives them attributes ansd adds them to a list

            List<User> Users = new List<User>();

            User User1 = new User();

            User1.Id = "A001";

            User1.Name = "Daniel";

            User1.Password = "password";

            User1.Balance = 100;

            User User2 = new User();

            User2.Id = "A002";

            User2.Name = "Piper";

            User2.Password = "password2";

            User2.Balance = 200;

            Users.Add(User1);
            Users.Add(User2);



            while (true)
            {
                User SelectedUser = null;
                
                User AchtiveUser = null;
                
                bool quit = false;
                
                //This code prompts the user to enter the ID of the account they wish to access

                Console.WriteLine("Welcome to Njord ATM.");

                while (SelectedUser == null)
                {
                    
                    Console.WriteLine("Please enter your account ID");
                    string id = Console.ReadLine();

                    SelectedUser = idChecker(id, Users);
                }

                //This code prompts the user to enter the password of the account they wish to access

                while (AchtiveUser == null)
                {
                    Console.WriteLine("Please enter the password for account " + SelectedUser.Id);
                    string password = Console.ReadLine();

                    AchtiveUser = passwordChecker(password, SelectedUser);
                }

                while (quit == false)
                {
                    quit = homePage(AchtiveUser, Users);
                    
                }
            }
        }

        //this funtcion checks that the ID that the user entered is valid

        static User idChecker(string id, List<User> Users)
        {
            foreach  (User usr in Users)
            {
                if (id.ToUpper() == usr.Id)
                {
                    return usr;
                }
            }

            Console.WriteLine("ERROR: User not found");

            return null;
        }

        //this funtcion checks that the Password that the user entered matches that of the selected account

        static User passwordChecker(string password, User SelectedUser)
        {
            if (password == SelectedUser.Password)
            {
                return SelectedUser;
            }

            Console.WriteLine("ERROR: Password not valid");

            return null;
        }

        //This function displays a list actions which the user can carry out

        static bool homePage(User AchtiveUser, List<User> Users)
        {
            Console.WriteLine("ID: " + AchtiveUser.Id);

            Console.WriteLine("Name: " + AchtiveUser.Name);

            Console.WriteLine("Balance: £" + AchtiveUser.Balance);

            Console.WriteLine("1: Withdraw");

            Console.WriteLine("2: Deposit");

            Console.WriteLine("3: Transfer");

            Console.WriteLine("4: Quit");
            
            bool inputcheck = false;

            while (inputcheck == false)
            {
                Console.WriteLine("Which of these options would you like to pick?");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        withdraw(AchtiveUser, Users);
                        inputcheck = true;
                        break;
                    case "2":
                        deposit(AchtiveUser, Users);
                        inputcheck = true;
                        break;
                    case "3":
                        transaction(AchtiveUser, Users);
                        inputcheck = true;
                        break;
                    case "4":
                        Console.WriteLine("Quitting...");
                        inputcheck = true;
                        break;
                    default:
                        Console.WriteLine("ERROR: Incorrect input!");
                        break;
                }
            }
            return true;
        }

        //This function allows users to withdraw funds from their accounts

        static void withdraw(User AchtiveUser, List<User> Users)
        {
            Console.WriteLine("Balance: £" + AchtiveUser.Balance);

            Console.WriteLine("1: £10 \r\n2: £20 \n\r3: £50\r\n4: £100\r\n5: £200\r\n6: Cancel");

            bool transactioncomplete = false;

            while (transactioncomplete == false)
            {
                Console.WriteLine("Please select the amount of money you would like to withdraw.");
                string Amount = Console.ReadLine();

                switch (Amount)
                {
                    case "1":
                        if (AchtiveUser.Balance < 10)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 10;
                        Console.WriteLine("Money withdrawn successfully.");
                        transactioncomplete = true;
                        break;
                    case "2":
                        if (AchtiveUser.Balance < 20)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 20;
                        Console.WriteLine("Money withdrawn successfully.");
                        transactioncomplete = true;
                        break;
                    case "3":
                        if (AchtiveUser.Balance < 50)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 50;
                        Console.WriteLine("Money withdrawn successfully.");
                        transactioncomplete = true;
                        break;
                    case "4":
                        if (AchtiveUser.Balance < 100)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 100;
                        Console.WriteLine("Money withdrawn successfully.");
                        transactioncomplete = true;
                        break;
                    case "5":
                        if (AchtiveUser.Balance < 200)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 200;
                        Console.WriteLine("Money withdrawn successfully.");
                        transactioncomplete = true;
                        break;
                    case "6":
                        Console.WriteLine("Cancelling...");
                        transactioncomplete = true;
                        break;
                    default:
                        Console.WriteLine("ERROR: Incorrect input!");
                        break;
                }
            }
        }

        //This function allows users to deposit funds into their accounts

        static void deposit(User AchtiveUser, List<User> Users)
        {
            Console.WriteLine("Balance: £" + AchtiveUser.Balance);

            Console.WriteLine("1: £10 \r\n2: £20 \n\r3: £50\r\n4: £100\r\n5: £200\r\n6: Cancel");

            bool transactioncomplete = false;

            while (transactioncomplete == false)
            {
                Console.WriteLine("Please select the amount of money you would like to withdraw.");
                string Amount = Console.ReadLine();

                switch (Amount)
                {
                    case "1":
                        AchtiveUser.Balance = AchtiveUser.Balance + 10;
                        Console.WriteLine("Money deposited successfully");
                        transactioncomplete = true;
                        break;
                    case "2":
                        AchtiveUser.Balance = AchtiveUser.Balance + 20;
                        Console.WriteLine("Money deposited successfully");
                        transactioncomplete = true;
                        break;
                    case "3":
                        AchtiveUser.Balance = AchtiveUser.Balance + 50;
                        Console.WriteLine("Money deposited successfully");
                        transactioncomplete = true;
                        break;
                    case "4":
                        AchtiveUser.Balance = AchtiveUser.Balance + 100;
                        Console.WriteLine("Money deposited successfully");
                        transactioncomplete = true;
                        break;
                    case "5":
                        AchtiveUser.Balance = AchtiveUser.Balance + 200;
                        Console.WriteLine("Money deposited successfully");
                        transactioncomplete = true;
                        break;
                    case "6":
                        Console.WriteLine("Cancelling...");
                        transactioncomplete = true;
                        break;
                    default:
                        Console.WriteLine("ERROR: Incorrect input!");
                        break;
                }
            }
        }

        //This function allows users to transfer funds from their accounts to those of other users

        static void transaction(User AchtiveUser, List<User> Users)
        {
            User RecievingUser = null;

            while (RecievingUser == null)
            {
                Console.WriteLine("Which account would you like to send money to?");
                string TransferRequest = Console.ReadLine();

                RecievingUser = userChecker(TransferRequest, Users);
            }

            Console.WriteLine("Balance: £" + AchtiveUser.Balance);

            Console.WriteLine("1: £10 \r\n2: £20 \n\r3: £50\r\n4: £100\r\n5: £200\r\n6: Cancel");

            bool TransactionComplete = false;

            while (TransactionComplete == false)
            {
                Console.WriteLine("Please select the amount of money you would like to send.");
                string Amount = Console.ReadLine();

                switch (Amount)
                {
                    case "1":
                        if (AchtiveUser.Balance < 10)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 10;
                        RecievingUser.Balance = RecievingUser.Balance + 10;
                        Console.WriteLine("Money transferred successfully");
                        TransactionComplete = true;
                        break;

                    case "2":
                        if (AchtiveUser.Balance < 20)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 20;
                        RecievingUser.Balance = RecievingUser.Balance + 20;
                        Console.WriteLine("Money transferred successfully");
                        TransactionComplete = true;
                        break;

                    case "3":
                        if (AchtiveUser.Balance < 50)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 50;
                        RecievingUser.Balance = RecievingUser.Balance + 50;
                        Console.WriteLine("Money transferred successfully");
                        TransactionComplete = true;
                        break;

                    case "4":
                        if (AchtiveUser.Balance < 100)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 100;
                        RecievingUser.Balance = RecievingUser.Balance + 100;
                        Console.WriteLine("Money transferred successfully");
                        TransactionComplete = true;
                        break;

                    case "5":
                        if (AchtiveUser.Balance < 200)
                        {
                            Console.WriteLine("ERROR: Insufficient funds");
                            break;
                        }
                        AchtiveUser.Balance = AchtiveUser.Balance - 200;
                        RecievingUser.Balance = RecievingUser.Balance + 200;
                        Console.WriteLine("Money transferred successfully");
                        TransactionComplete = true;
                        break;

                    case "6":
                        Console.WriteLine("Cancelling...");
                        TransactionComplete = true;
                        break;

                    default:
                        Console.WriteLine("ERROR: Incorrect input");
                        break;
                }
            }
        }

        //This code checks that the username of the recieving user is valid

        static User userChecker(string user, List<User> Users)
        {
            foreach (User usr in Users)
            {
                if (user.ToUpper() == usr.Name.ToUpper())
                {
                    return usr;
                }
            }

            Console.WriteLine("ERROR: User not found");

            return null;
        }
    }
}
